<?php 

// admin menu pengaturan WP Masjid

?>

    <div class="lmenu">
		<div class="welcome curs"><i class="fa fa-home"></i> <span>DASBOR TEMA</span></div>
		<div class="setting curs"><i class="fa fa-navicon"></i> <span>DATA MASJID</span></div>
		<div class="styles curs"><i class="fa fa-users"></i> <span>JADWAL SHALAT</span></div>
		<div class="layout curs"><i class="fa fa-cube"></i> <span>LOGO & FAVICON</span></div>
		<div class="change curs"><i class="fa fa-edit"></i> <span>REPLACE TEXT</span></div>
		<div class="external curs"><i class="fa fa-star"></i> <span>DEVELOPER TEMA</span></div>
	</div>