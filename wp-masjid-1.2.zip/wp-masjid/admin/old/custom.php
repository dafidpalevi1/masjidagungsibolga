
		
	    <?php get_template_part('admin/color/global'); ?>
	    <?php get_template_part('admin/color/header'); ?>
		<?php get_template_part('admin/color/slider'); ?>
		<?php get_template_part('admin/color/info'); ?>
		<?php get_template_part('admin/color/search'); ?>
		<?php get_template_part('admin/color/package'); ?>
		<?php get_template_part('admin/color/after'); ?>
		<?php get_template_part('admin/color/additional'); ?>
		<?php get_template_part('admin/color/partner'); ?>
		<?php get_template_part('admin/color/eventgal'); ?>
		<?php get_template_part('admin/color/testimoni'); ?>
		
		<?php get_template_part('admin/color/bread'); ?>
		<?php get_template_part('admin/color/archive'); ?>
		<?php get_template_part('admin/color/pagination'); ?>
		<?php get_template_part('admin/color/single'); ?>
		<?php get_template_part('admin/color/sidebar'); ?>
		
		<?php get_template_part('admin/color/footbar'); ?>
		<?php get_template_part('admin/color/footer'); ?>
