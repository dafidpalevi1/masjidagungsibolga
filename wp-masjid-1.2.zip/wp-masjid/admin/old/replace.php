	
		<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('REPLACE TEXT', 'weesata'); ?></label>
			</td>
	    	<td> 
	        	<div class="">
				    <div>
				        Pengaturan Replace Text disedikan untuk merubah text default bawaan tema. 
					</div>
				</div>
			</td>
     	</tr>
		
    	<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('TOP HEADER', 'weesata'); ?></label>
			</td>
	    	<td> 
	        	<div class="clear">
				    <div class="quarter">
				       <label>Fax</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="refax" id="refax" class="widefat" placeholder="misal, Fax..." value="<?php echo get_option('refax'); ?>"/> 
					</div>
				</div>
				<div class="clear">
				    <div class="quarter">
				       <label>Email</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="remail" id="remail" class="widefat" placeholder="misal, Email..." value="<?php echo get_option('remail'); ?>"/> 
					</div>
				</div>
				<div class="clear">
				    <div class="quarter">
				       <label>Cari Berita</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="recaber" id="recaber" class="widefat" placeholder="misal, Cari Artikel..." value="<?php echo get_option('recaber'); ?>"/> 
					</div>
				</div>
				<div class="clear">
				    <div class="quarter">
				       <label>Online Hour</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="reonhour" id="reonhour" class="widefat" placeholder="misal, Online Time..." value="<?php echo get_option('reonhour'); ?>"/> 
					</div>
				</div>
			</td>
     	</tr>
		
    	<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('SEKILAS INFO', 'weesata'); ?></label>
			</td>
	    	<td> 
	        	<div class="clear">
				    <div class="quarter">
				       <label>Sekilas Info</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="reinfo" id="reinfo" class="widefat" placeholder="misal, Info Sekilas..." value="<?php echo get_option('reinfo'); ?>"/> 
					</div>
				</div>
			</td>
		</tr>
		
		<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('PROMO', 'weesata'); ?></label>
			</td>
	    	<td> 
	        	<div class="clear">
				    <div class="quarter">
				       <label>Promo !!!</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="repromo" id="repromo" class="widefat" placeholder="misal, Diskon..." value="<?php echo get_option('repromo'); ?>"/> 
					</div>
				</div>
			</td>
		</tr>
		
		<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('BLOCK INFO', 'weesata'); ?></label>
			</td>
	    	<td> 
				<div class="clear">
				    <div class="quarter">
				       <label>Pesan Sekarang..</label> 
					</div>
					<div class="trequarter">
				        <?php $settings = array(
									    	'teeny' => true,
											'textarea_rows' => 4,
											'tabindex' => 1
											);
											$content = get_option('pesan');
											wp_editor(stripslashes($content), 'pesan', $settings);
										?>
										<br/>
										Replace text : <em>Pesan Sekarang, jangan sampe kehabisan Kuota !!!</em>
										
					</div>
				</div>
				
				<div class="clear">
				    <div class="quarter">
				       <label>Deskripsi</label> 
					</div>
					<div class="trequarter">
				       <?php $settings = array(
									    	'teeny' => true,
											'textarea_rows' => 4,
											'tabindex' => 1
											);
											$content = get_option('deskripsi');
											wp_editor(stripslashes($content), 'deskripsi', $settings);
										?>
										<br/>
										Replace text : <em>Kami selalu berikan promo-promo menarik, mengunjungi tempat-tempat indah yang akan memanjakan liburan Anda</em> 
					</div>
				</div>
				<div class="clear">
				    <div class="quarter">
				       <label>Lihat Paket</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="lihat" id="lihat" class="widefat" placeholder="misal, Lihat Paket..." value="<?php echo get_option('lihat'); ?>"/> 
					</div>
				</div>
			</td>
		</tr>
		
		<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('TEXT TAMBAHAN', 'weesata'); ?></label>
			</td>
			<td>
				<div class="clear">
				    <div class="quarter">
				       <label>Left Block</label> 
					</div>
					<div class="trequarter">
				        <?php $settings = array(
								'teeny' => true,
								'textarea_rows' => 8,
								'tabindex' => 1
								);
							$content = get_option('addleft');
							wp_editor(stripslashes($content), 'addleft', $settings);
						?>
						<br/>
										
					</div>
				</div>
				
				<div class="clear">
				    <div class="quarter">
				       <label>Right Block</label> 
					</div>
					<div class="trequarter">
				        <?php $settings = array(
								'teeny' => true,
								'textarea_rows' => 8,
								'tabindex' => 1
								);
							$content = get_option('addright');
							wp_editor(stripslashes($content), 'addright', $settings);
						?>
						<br/>
										
					</div>
				</div>
			</td>
		</tr>
		
		<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('PARTNER', 'weesata'); ?></label>
			</td>
	    	<td> 
				<div class="clear">
				    <div class="quarter">
				       <label>Partner Kami</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="partner" id="partner" class="widefat" placeholder="misal, Partner Kami..." value="<?php echo get_option('partner'); ?>"/> 
					</div>
				</div>
			</td>
		</tr>
		
		<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('AGENDA + GALERI', 'weesata'); ?></label>
			</td>
	    	<td> 
				<div class="clear">
				    <div class="quarter">
				       <label>Cek Agenda</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="cek" id="cek" class="widefat" placeholder="misal, Cek Agenda..." value="<?php echo get_option('cek'); ?>"/> 
					</div>
				</div>
				<div class="clear">
				    <div class="quarter">
				       <label>Cek Galeri</label> 
					</div>
					<div class="trequarter">
				       <input type="text" name="cekgal" id="cekgal" class="widefat" placeholder="misal, Cek Galeri..." value="<?php echo get_option('cekgal'); ?>"/> 
					</div>
				</div>
			</td>
     	</tr>
		
		
		<tr valign="top">
        	<td class="tl">
		    	<label for="headbg"><?php _e('FOOTER', 'weesata'); ?></label>
			</td>
	    	<td>
				<div class="clear">
				    <div class="quarter">
				       <label>Footer</label> 
					</div>
					<div class="trequarter">
				        <?php $settings = array(
								'teeny' => true,
								'textarea_rows' => 4,
								'tabindex' => 1
								);
							$content = get_option('footer');
							wp_editor(stripslashes($content), 'footer', $settings);
						?>
						<br/>
						Replace text : <em>Copyright © 2017 WP Compro , Tema...</em>
										
					</div>
				</div>
			</td>
     	</tr>
		