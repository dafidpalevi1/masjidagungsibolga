<?php 

/* 
// Data profile perusahaan lengkap
*/

?>

            <script>
		    	jQuery(document).ready(function($){
		    		$('.blogo_url').click(function() {
				    	var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						wp.media.editor.send.attachment = function(props, attachment) {
						jQuery(".custom_logo").attr('src', attachment.url);
						$(button).prev().val(attachment.url);
						wp.media.editor.send.attachment = send_attachment_bkp;
						$('.custom_logo, .lek').show();
						}
						wp.media.editor.open(button);
						return false;  
					});
					$(".lek").click(function(){
						$('#logo_url').val('');
						$('.custom_logo, .lek').hide();
					});
					
					$('.favicons').click(function() {
				    	var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						wp.media.editor.send.attachment = function(props, attachment) {
						jQuery(".custom_favicon").attr('src', attachment.url);
						$(button).prev().val(attachment.url);
						wp.media.editor.send.attachment = send_attachment_bkp;
						$('.custom_favicon, .fak').show();
						}
						wp.media.editor.open(button);
						return false;  
					});
					$(".fak").click(function(){
						$('#favicon').val('');
						$('.custom_favicon, .fak').hide();
					});
				});
			</script>
    <tr valign="top">
    	<td class="tl"><label for="perusahaan"><?php _e('COMPANY PROFILE', 'medika'); ?></label></td>
		<td>
	    	<span class="description">Lengkapi data profile, mencakup data umum dan informasi kontak</span>
    	</td>
	</tr>
	
	<tr>
		<td class="tl"><label>Ganti Logo</label></td>
    	<td>
	
         	<div class="pekol">
		    	<?php if (get_option('logo_url')) { ?>
		    		<span class="lek bl">x</span>
		    	<?php } else { ?>
		    		<span class="lek no">x</span>
		    	<?php } ?>
		    	<img class="custom_logo" src="<?php echo get_option('logo_url'); ?>"/><br/>
			</div>
	    	<div class="pekol">
			    <input class="custom_media_url" id="logo_url" type="hidden" name="logo_url" value="<?php echo get_option('logo_url'); ?>"> <a href="#" class="button blogo_url custom_media_upload">Upload Logo</a><br/>
			</div>
	
        	<span class="description"><strong>PENTING</strong> : Siapkan gambar logo 400x100 pixel atau skala kelipatannya. Gunakan gambar berformat <strong>PNG transparan</strong> (tembus pandang) atau gambar berformat JPG dengan background  serupa header</span>
			<br/><br/>
    	</td>
	</tr>
	
	<tr>
		<td class="tl"><label>Ganti Ikon Website</label></td>
    	<td>
	
         	<div class="pekol">
		    	<?php if (get_option('favicon')) { ?>
		    		<span class="fak bl">x</span>
		    	<?php } else { ?>
		    		<span class="fak no">x</span>
		    	<?php } ?>
		    	<img class="custom_favicon" src="<?php echo get_option('favicon'); ?>"/><br/>
			</div>
	    	<div class="pekol">
			    <input class="custom_media_url" id="favicon" type="hidden" name="favicon" value="<?php echo get_option('favicon'); ?>"> <a href="#" class="button favicons custom_media_upload">Upload Favicon</a><br/>
			</div>
	
        	<span class="description"><strong>PENTING</strong> : Untuk favicon (ikon header website) pergunakan gambar persegi dengan ukuran 1:1 (misal 64x64 pixel) dan format jpg, gif, atau png</span>
			<br/><br/>
    	</td>
	</tr>
	
	<script>
		    	jQuery(document).ready(function($){
		    		$('.afterbg').click(function() {
				    	var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						wp.media.editor.send.attachment = function(props, attachment) {
						jQuery(".custom_headbg").attr('src', attachment.url);
						$(button).prev().val(attachment.url);
						wp.media.editor.send.attachment = send_attachment_bkp;
						$('.custom_headbg, .aek').show();
						}
						wp.media.editor.open(button);
						return false;  
					});
					$(".aek").click(function(){
						$('#afbg').val('');
						$('.custom_headbg, .aek').hide();
					});
				});
            </script>
        			
	<tr valign="top">
	    <td class="tl">
		    <label for="headbg">FOTO PIMPINAN</label>
		</td>
	    <td>
		    <div class="pekol">
		        <?php if (get_option('direktur')) { ?>
		    	    <span class="aek bl">x</span>
		        <?php } else { ?>
		        	<span class="aek no">x</span>
		        <?php } ?>
		        <img class="custom_headbg" src="<?php echo get_option('direktur'); ?>"/><br/>
		    </div>
	        <div class="pekol">
			    <input class="custom_media_url" id="direktur" type="hidden" name="direktur" value="<?php echo get_option('direktur'); ?>"> <a href="#" class="button afterbg custom_media_upload">Upload Gambar</a><br/>
		    </div>
	
            <span class="description"><strong>PENTING</strong> : Tambahkan foto Direktur, ukuran disarankan 300x300 px</span>
		    <br/><br/>
	    </td>
    </tr>
	
	<tr valign="top">
									    	<td class="tl"><label for="perusahaan"><?php _e('Nama Perusahaan', 'weesata'); ?></label></td>
											<td>
										    	<input type="text" name="perusahaan" id="perusahaan" size="50" value="<?php echo get_option('perusahaan'); ?>"/><span class="description"> <?php _e('contoh, CV. Weesata Tour & Travel', 'weesata'); ?></span>
									    	</td>
										</tr>
										<tr valign="top">
								    		<td class="tl"><label for="siup"><?php _e('SIUP', 'weesata'); ?></label></td>
									    	<td>
									        	<input type="text" name="siup" id="siup" size="50" value="<?php echo get_option('siup'); ?>"/><span class="description"> <?php _e('contoh, 551.21/3071/I/DISPAR', 'weesata'); ?></span>
									    	</td>
										</tr>
										<tr valign="top">
								    		<td class="tl"><label for="tdup"><?php _e('TDUP', 'weesata'); ?></label></td>
									    	<td>
									        	<input type="text" name="tdup" id="tdup" size="50" value="<?php echo get_option('tdup'); ?>"/><span class="description"> <?php _e('contoh, 01/01/52/DPMPTSP/2017', 'weesata'); ?></span>
									    	</td>
										</tr>
										<tr valign="top">
								    		<td class="tl"><label for="situ"><?php _e('SITU', 'weesata'); ?></label></td>
									    	<td>
									        	<input type="text" name="situ" id="situ" size="50" value="<?php echo get_option('situ'); ?>"/><span class="description"> <?php _e('contoh, 11/309/1430/DS/DPMPTSP/2017', 'weesata'); ?></span>
									    	</td>
										</tr>
										<tr valign="top">
								    		<td class="tl"><label for="npwp"><?php _e('NPWP', 'weesata'); ?></label></td>
									    	<td>
									        	<input type="text" name="npwp" id="npwp" size="50" value="<?php echo get_option('npwp'); ?>"/><span class="description"> <?php _e('contoh, 02.798.056.4-903.000', 'weesata'); ?></span>
									    	</td>
										</tr>
	
	<tr valign="top"> 
	<td class="tl"><label for="alamat"><?php _e('Alamat Kantor', 'medika'); ?></label></td>
	    <td>
		    <input type="text" class="widefat" name="alamat" id="alamat" size="50" value="<?php echo get_option('alamat'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top">
    	<td class="tl"><label for="maps"><?php _e('Koordinat', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="contoh, -5.932330 , 105.992419" class="widefat" name="maps" id="maps" size="50" value="<?php echo get_option('maps'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top">
    	<td class="tl"><label for="apikey"><?php _e('API Key Maps', 'medika'); ?></label></td>
		<td>
	    	<input type="text" class="widefat" name="apikey" id="apikey" size="50" value="<?php echo get_option('apikey'); ?>"/><span class="description"> <?php _e('dapatan kode API Key dari ', 'medika'); ?><a href="https://developers.google.com/maps/web/" target="_blank">Google Dev</a></span>
    	</td>
	</tr>
	
	<tr valign="top">
    	<td class="tl"><label for="kodepos"><?php _e('Kode Pos', 'medika'); ?></label></td>
	    	<td><input type="text" class="widefat" name="kodepos" id="kodepos" size="50" value="<?php echo get_option('kodepos'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top">
    	<td class="tl"><label for="telepon"><?php _e('Telepon', 'medika'); ?></label></td>
		<td>
	    	<input type="text" class="widefat" name="telepon" id="telepon" size="50" value="<?php echo get_option('telepon'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top">
    	<td class="tl"><label for="fax"><?php _e('Fax', 'medika'); ?></label></td>
		<td>
	    	<input type="text" class="widefat" name="fax" id="fax" size="50" value="<?php echo get_option('fax'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top"> 
    	<td class="tl"><label for="email"><?php _e('Email', 'medika'); ?></label></td>
		<td>
	    	<input type="text" class="widefat" name="email" id="email" size="50" value="<?php echo get_option('email'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top"> 
    	<td class="tl"><label for="email"><?php _e('Website', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="http://..." class="widefat" name="website" id="website" size="50" value="<?php echo get_option('website'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top"> 
	<td class="tl"><label for="facebook"><?php _e('Facebook', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="http://..." class="widefat" name="facebook" id="facebook" size="50" value="<?php echo get_option('facebook'); ?>"/><br/><br/>
			<input type="text" placeholder="Ciuss" class="widefat" name="fbacc" id="fbacc" size="50" value="<?php echo get_option('fbacc'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top">
    	<td class="tl"><label for="twitter"><?php _e('Twitter', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="http://..." class="widefat" name="twitter" id="twitter" size="50" value="<?php echo get_option('twitter'); ?>"/><br/><br/>
			<input type="text" placeholder="@selfishyayun" class="widefat" name="twitacc" id="twitacc" size="50" value="<?php echo get_option('twitacc'); ?>"/>
		</td>
	</tr>
	
	<tr valign="top">
    	<td class="tl"><label for="youtube"><?php _e('Instagram', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="http://..." class="widefat" name="instagram" id="instagram" size="50" value="<?php echo get_option('instagram'); ?>"/><br/><br/>
			<input type="text" placeholder="@selfishyayun" class="widefat" name="insacc" id="insacc" size="50" value="<?php echo get_option('insacc'); ?>"/>
		</td>
	</tr>
	
 	<tr valign="top"> 
    	<td class="tl"><label for="google"><?php _e('Google+', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="http://..." class="widefat" name="google" id="google" size="50" value="<?php echo get_option('google'); ?>"/>
    	</td>
	</tr>
	
	<tr valign="top">
    	<td class="tl"><label for="youtube"><?php _e('Youtube', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="http://..." class="widefat" name="youtube" id="youtube" size="50" value="<?php echo get_option('youtube'); ?>"/>
		</td>
	</tr>
	
	
	
    <tr valign="top">
        <td class="head" colspan="2">
    		<h3 style="font-size: 16px;">JAM KERJA KANTOR</h3>
    	</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label for="senin"><?php _e('SENIN', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="contoh, 08.00 - 21.00" class="widefat" name="senin" id="senin" size="50" value="<?php echo get_option('senin'); ?>"/>
    	</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label for="selasa"><?php _e('SELASA', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="contoh, 08.00 - 21.00" class="widefat" name="selasa" id="selasa" size="50" value="<?php echo get_option('selasa'); ?>"/>
    	</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label for="rabu"><?php _e('RABU', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="contoh, 08.00 - 21.00" class="widefat" name="rabu" id="rabu" size="50" value="<?php echo get_option('rabu'); ?>"/>
    	</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label for="kamis"><?php _e('KAMIS', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="contoh, 08.00 - 21.00" class="widefat" name="kamis" id="kamis" size="50" value="<?php echo get_option('kamis'); ?>"/>
    	</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label for="jumat"><?php _e('JUMAT', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="contoh, 08.00 - 21.00" class="widefat" name="jumat" id="jumat" size="50" value="<?php echo get_option('jumat'); ?>"/>
    	</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label for="sabtu"><?php _e('SABTU', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="contoh, 08.00 - 21.00" class="widefat" name="sabtu" id="sabtu" size="50" value="<?php echo get_option('sabtu'); ?>"/>
    	</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label for="minggu"><?php _e('MINGGU', 'medika'); ?></label></td>
		<td>
	    	<input type="text" placeholder="contoh, 08.00 - 21.00" class="widefat" name="minggu" id="minggu" size="50" value="<?php echo get_option('minggu'); ?>"/>
    	</td>
	</tr>
