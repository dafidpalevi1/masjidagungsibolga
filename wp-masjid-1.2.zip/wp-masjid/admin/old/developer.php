

    <tr valign="top">
	    <td colspan="2">
		    <div style="margin: -5px 0;">
	        <img style="display: block;" src="https://ciuss.com/wp-content/themes/ciuss/images/ciuss.jpg" width="100%"/>
			</div>
		</td>
	</tr>
	<tr valign="top">
	    <td class="tl"><label for="sekilas"><img src="<?php echo get_template_directory_uri(); ?>/images/dev.jpg" class="dev" /></label></td>
		<td>
			<label>DEVELOPER</label><br/><br/>
			Untuk support seputar bug dan masalah eror harap dilaporkan kepada developer agar segera diperbaiki. Kerusakan tema dikarenakan custom yang dilakukan pengguna tidak dilayani perbaikannya
		    <br/><br/>
			Berikut adalah alternatif  kontak yang dapat digunakan untuk menghubungi developer
		</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>NAMA ALIAS</label></td>
		<td>yayun</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>TELEPON</label></td>
		<td>0838-1525-1385</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>EMAIL</label></td>
		<td>yayun@ciuss.com</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>FACEBOOK</label></td>
		<td><a href="https://facebook.com/ciussgw" target="_target">facebook.com/ciussgw</a></td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>WEBSITE</label></td>
		<td><a href="https://ciuss.com" target="_target">ciuss.com</a></td>
	</tr>