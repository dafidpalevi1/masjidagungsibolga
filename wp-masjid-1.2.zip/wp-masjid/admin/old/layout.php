
        <tr valign="top">
	        <td class="tl">
		    	<label for="sekilas"><?php _e('Layout Setting', 'weesata'); ?></label>
			</td>
	    	<td>
		    	Pengaturan Layout disediakan untuk pengguna dapat memilih style yang disediakan oleh tema. Juga untuk menyembunyikan fitur yang mungkin tidak dibutuhkan.
	    	</td>
        </tr>
	
	    <tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Layout Tema</label>
			</td>
	     	<td>
			    <div class="clear">
				    	Pengaturan tampilan pada layar Desktop (komputer dan laptop) 
		    	</div>
				
				<div class="clear">
		    		<div class="quarter">
				    	<span class="bold"><?php _e('Layout Tema', 'weesata'); ?></span> 
		    		</div>
					<div class="quarter">
			 	   	    <input type="radio" name="boxed" value="boxed" <?php echo (get_option('boxed') == 'boxed') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Boxed', 'weesata'); ?></span> 
		    		</div>
		    		<div class="quarter">
		    			<input type="radio" name="boxed" value="noboxed" <?php echo (get_option('boxed') == 'noboxed') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Full-width', 'weesata'); ?></span>
		    		</div>
				</div>
			</td>
		</tr>
			
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Form Shortcode</label>
			</td>
	     	<td>
			    <div class="clear">
				    Masukkan angka ID shortcode form dari Contak Form 7 untuk ditampilkan pada halaman Kontak. Gunakan plugin Contact Form 7 yang dapat di instal melalui
					<strong>Dasbor</strong> > <strong>Plugin</strong> > <strong>Tambah Baru</strong><br/><br/>
		    	</div>
				
				<div class="clear">
		    		<div class="quarter">
				    	<span class="bold"><?php _e('Shortcode ID', 'weesata'); ?></span> 
		    		</div>
					<div class="quarter">
		    			<input type="text" name="scode" id="scode" class="widefat" placeholder="..." value="<?php echo get_option('scode'); ?>"/> 
		    		</div>
				</div>
			</td>
		</tr>
		
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Ikon Header</label>
			</td>
	     	<td>
				<div class="clear">
			    	Pilih bentuk tampilan dari ikon header<br/>
		    	</div>
				<div class="clear">
		        	<div class="quarter">
		    	    	<input type="radio" name="icohed" value="circle" <?php echo (get_option('icohed') == 'circle') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Lingkaran', 'weesata'); ?></span>
		        	</div>
			    	<div class="quarter">
		        		<input type="radio" name="icohed" value="square" <?php echo (get_option('icohed') == 'square') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Kotak', 'weesata'); ?></span>
		        	</div>
				</div>
	    	</td>
    	</tr>
		
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Sekilas Info</label>
			</td>
	     	<td>
				<div class="clear">
			    	Pilih menampilkan atau tidak text Sekilas Info pada bagian kiri Text Berjalan<br/>
		    	</div>
				<div class="clear">
		        	<div class="quarter">
		    	    	<input type="radio" name="sinon" value="on" <?php echo (get_option('sinon') == 'on') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Tampilkan', 'weesata'); ?></span>
		        	</div>
			    	<div class="quarter">
		        		<input type="radio" name="sinon" value="off" <?php echo (get_option('sinon') == 'off') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Sembunyikan', 'weesata'); ?></span>
		        	</div>
				</div>
	    	</td>
    	</tr>
		
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Slideshow</label>
			</td>
	     	<td>
				<div class="clear">
			    	Fitur on / off untuk text dalam slideshow. Silahkan di nonaktifkan jika tidak dibutuhkan dan hanya ingin menampilkan gambar<br/>
		    	</div>
				<div class="clear">
		        	<div class="quarter">
		    	    	<input type="radio" name="onslide" value="on" <?php echo (get_option('onslide') == 'on') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Aktifkan', 'weesata'); ?></span>
		        	</div>
			    	<div class="quarter">
		        		<input type="radio" name="onslide" value="off" <?php echo (get_option('onslide') == 'off') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Non Aktif', 'weesata'); ?></span>
		        	</div>
				</div>
	    	</td>
    	</tr>
		
				<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Ukuran Slide</label>
			</td>
			<td>
			    <div>
			    	Pengaturan ukuran gambar Slide saat ini <?php echo (get_option('swidth')) ? get_option('swidth') : '1200' ?> x <?php echo (get_option('sheight')) ? get_option('sheight') : '500' ?> (default bawaan tema adalah 1200 x 500 pixel)<br/><br/>
		    	</div>
				<div class="clear">
				    <div class="quarter">
					    <label>Width</label>
					</div>
			    	<div class="quarter">
			        	<input type="text" name="swidth" id="swidth" class="widefat" placeholder="misal, 1000..." value="<?php echo get_option('swidth'); ?>"/> 
		         	</div>
				</div>
				<div class="clear">
					<div class="quarter">
					    <label>Height</label>
					</div>
			    	<div class="quarter">
			        	<input type="text" name="sheight" id="sheight" class="widefat" placeholder="misal, 650..." value="<?php echo get_option('sheight'); ?>"/> 
		         	</div>
					<br/><br/>
					<span class="description"><strong>PENTING</strong> : Perubahan ukuran slide tidak akan berpengaruh pada gambar yang telah di upload sebelum setting ini di atur. Ukuran baru akan bekerja pada gambar yang di upload setelah setting ini dilakukan. JIka Anda tetap ingin ukuran gambar baru ini bekerja pada gambar-gambar tersebut maka perlu mengatur ulang seluruh gambar (regenerate thumbnail) dan saran adalah dengan menggunakan plugin 
					<a href="https://wordpress.org/plugins/regenerate-thumbnails/" target="_blank"> Regenerate Thumbnails</a> (Alex Mills) atau plugin yang memiliki fungsi serupa<br/><br/>
		        	</span>
					<br/><br/>
				</div>
			</td>
		</tr>
		
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Itinerary Home</label>
			</td>
	     	<td>
				<div class="clear">
			    	Fitur untuk mengatur tampilan on / off itinerary pada daftar paket di Home<br/>
		    	</div>
				
				<div class="clear">
					<div class="quarter">
				    	<input type="radio" name="oniti" value="on" <?php echo (get_option('oniti') == 'on') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Aktifkan', 'weesata'); ?></span> 
		    		</div>
		    		<div class="quarter">
		    			<input type="radio" name="oniti" value="off" <?php echo (get_option('oniti') == 'off') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Non Aktif', 'weesata'); ?></span>
		    		</div>
				</div>
				
	    	</td>
    	</tr>
		
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Animasi Promo</label>
			</td>
	     	<td>
				<div class="clear">
			    	Pilih menampilkan atau tidak animasi pada info PROMO !!!<br/>
		    	</div>
				<div class="clear">
		        	<div class="quarter">
		    	    	<input type="radio" name="infopro" value="on" <?php echo (get_option('infopro') == 'on') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Aktifkan', 'weesata'); ?></span>
		        	</div>
			    	<div class="quarter">
		        		<input type="radio" name="infopro" value="off" <?php echo (get_option('infopro') == 'off') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Non Aktif', 'weesata'); ?></span>
		        	</div>
				</div>
	    	</td>
    	</tr>
		
		<script>
		    	jQuery(document).ready(function($){
		    		$('.emerge').click(function() {
				    	var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						wp.media.editor.send.attachment = function(props, attachment) {
						jQuery(".emtes").attr('src', attachment.url);
						$(button).prev().val(attachment.url);
						wp.media.editor.send.attachment = send_attachment_bkp;
						$('.emtes, .emr').show();
						}
						wp.media.editor.open(button);
						return false;  
					});
					$(".emr").click(function(){
						$('#paral').val('');
						$('.emtes, .emr').hide();
					});
				});
            </script>
        			
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Parallax BG</label>
			</td>
	     	<td>
				
			    <div class="clear">
			    	Gambar latar untuk bagian Parallax, muncul jika background dibuat opacity / transparan
		    	</div>
		    	<div class="pekol">
		        	<?php if (get_option('paral')) { ?>
		    	    	<span class="emr bl">x</span>
		        	<?php } else { ?>
		        		<span class="emr no">x</span>
		        	<?php } ?>
		        	<img class="emtes" src="<?php echo get_option('paral'); ?>"/><br/>
		    	</div>
	         	<div class="pekol">
			        <input class="custom_media_url" id="paral" type="hidden" name="paral" value="<?php echo get_option('paral'); ?>"> <a href="#" class="button emerge custom_media_upload">Upload Gambar</a><br/>
		     	</div>
	
            	<span class="description"><strong>PENTING</strong> : Ukuran gambar dianjurkan minimal width 800x600 px atau lebih besar</span>
		    	<br/><br/>
	    	</td>
    	</tr>
		
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Additional Text</label>
			</td>
	     	<td>
				<div class="clear">
			    	Pilih menampilkan atau tidak block text tambahan pada home (Additional Text)<br/>
		    	</div>
				<div class="clear">
		        	<div class="quarter">
		    	    	<input type="radio" name="addinfo" value="on" <?php echo (get_option('addinfo') == 'on') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Aktifkan', 'weesata'); ?></span>
		        	</div>
			    	<div class="quarter">
		        		<input type="radio" name="addinfo" value="off" <?php echo (get_option('addinfo') == 'off') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Non Aktif', 'weesata'); ?></span>
		        	</div>
				</div>
	    	</td>
    	</tr>
		
		<script>
		    	jQuery(document).ready(function($){
		    		$('.jadwals').click(function() {
				    	var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						wp.media.editor.send.attachment = function(props, attachment) {
						jQuery(".emjad").attr('src', attachment.url);
						$(button).prev().val(attachment.url);
						wp.media.editor.send.attachment = send_attachment_bkp;
						$('.emjad, .dok').show();
						}
						wp.media.editor.open(button);
						return false;  
					});
					$(".dok").click(function(){
						$('#partes').val('');
						$('.emjad, .dok').hide();
					});
				});
            </script>
        			
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Testimoni BG</label>
			</td>
	     	<td>
				
			    <div class="clear">
			    	Gambar latar untuk bagian Testimoni, muncul jika background dibuat opacity / transparan
		    	</div>
		    	<div class="pekol">
		        	<?php if (get_option('partes')) { ?>
		    	    	<span class="dok bl">x</span>
		        	<?php } else { ?>
		        		<span class="dok no">x</span>
		        	<?php } ?>
		        	<img class="emjad" src="<?php echo get_option('partes'); ?>"/><br/>
		    	</div>
	         	<div class="pekol">
			        <input class="custom_media_url" id="partes" type="hidden" name="partes" value="<?php echo get_option('partes'); ?>"> <a href="#" class="button jadwals custom_media_upload">Upload Gambar</a><br/>
		     	</div>
	
            	<span class="description"><strong>PENTING</strong> : Ukuran gambar dianjurkan minimal width 800x600 px atau lebih besar</span>
		    	<br/><br/>
	    	</td>
    	</tr>
		
		<script>
		    	jQuery(document).ready(function($){
		    		$('.para').click(function() {
				    	var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						wp.media.editor.send.attachment = function(props, attachment) {
						jQuery(".cus_para").attr('src', attachment.url);
						$(button).prev().val(attachment.url);
						wp.media.editor.send.attachment = send_attachment_bkp;
						$('.cus_para, .pek').show();
						}
						wp.media.editor.open(button);
						return false;  
					});
					$(".pek").click(function(){
						$('#compar').val('');
						$('.cus_para, .pek').hide();
					});
				});
            </script>
        			
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">After Menu BG</label>
			</td>
	     	<td>
			    <div>
			    	Pengaturan untuk background bagian bawah setelah Menu. Pengguna dapat mengganti gambar background dengan gambar lain. 
		    	</div>
		    	<div class="pekol">
		        	<?php if (get_option('compar')) { ?>
		    	    	<span class="pek bl">x</span>
		        	<?php } else { ?>
		        		<span class="pek no">x</span>
		        	<?php } ?>
		        	<img class="cus_para" src="<?php echo get_option('compar'); ?>"/><br/>
		    	</div>
	         	<div class="pekol">
			        <input class="custom_media_url" id="compar" type="hidden" name="compar" value="<?php echo get_option('compar'); ?>"> <a href="#" class="button para custom_media_upload">Upload Gambar</a><br/>
		     	</div>
				
            	<span class="description"><strong>PENTING</strong> : Gambar yang di upload akan tampil full-width.</span>
		    	<br/><br/>
			</td>
		</tr>
		
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">GOOGLE MAPS</label>
			</td>
			<td>
			    <div>
			    	Pengaturan tinggi Maps, Zoom, dan custom Marker<br/><br/>
		    	</div>
				<div class="clear">
				    <div class="quarter">
					    <label>Maps Zoom</label>
					</div>
			    	<div class="trequarter">
			        	<input type="text" name="zoom" id="zoom" class="widefat" placeholder="masukkan angka 1 - 21..." value="<?php echo get_option('zoom'); ?>"/> 
		         	</div>
					<br/>
				</div>
				<div class="clear">
				    <div class="quarter">
					    <label>Maps Height</label>
					</div>
			    	<div class="trequarter">
			        	<input type="text" name="height" id="height" class="widefat" placeholder="misal, 300px..." value="<?php echo get_option('height'); ?>"/> 
		         	</div>
					<br/><br/>
				</div>
			</td>
		</tr>
	            <script>
		    	jQuery(document).ready(function($){
		    		$('.commaps').click(function() {
				    	var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						wp.media.editor.send.attachment = function(props, attachment) {
						jQuery(".cus_mark").attr('src', attachment.url);
						$(button).prev().val(attachment.url);
						wp.media.editor.send.attachment = send_attachment_bkp;
						$('.cus_mark, .mark').show();
						}
						wp.media.editor.open(button);
						return false;  
					});
					$(".mark").click(function(){
						$('#mmaps').val('');
						$('.cus_mark, .mark').hide();
					});
				});
            </script>
        			
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">MAPS MARKER</label>
			</td>
	     	<td>
			    <div>
			    	Tambahkan gambar untuk penanda lokasi maps.
		    	</div>
		    	<div class="pekol">
		        	<?php if (get_option('mmaps')) { ?>
		    	    	<span class="mark bl">x</span>
		        	<?php } else { ?>
		        		<span class="mark no">x</span>
		        	<?php } ?>
		        	<img class="cus_mark" src="<?php echo get_option('mmaps'); ?>"/><br/>
		    	</div>
	         	<div class="pekol">
			        <input class="custom_media_url" id="mmaps" type="hidden" name="mmaps" value="<?php echo get_option('mmaps'); ?>"> <a href="#" class="button commaps custom_media_upload">Upload Gambar</a><br/>
		     	</div>
	
            	<span class="description"><strong>PENTING</strong> : Gunakan gambar berformat PNG (transparan) dengan ukuran kotak (misal 100x100 pixel)</span>
		    	<br/><br/>
	    	</td>
    	</tr>
		
		<tr valign="top">
	    	<td class="tl">
			    <label for="headbg">Footer Logo</label>
			</td>
	     	<td>
			    <div class="clear">
			    	Fitur on / off bagian Logo bagian Footer. Silahkan di nonaktifkan jika tidak dibutuhkan<br/>
		        	<br/>
			    	<div class="quarter">
			        	<input type="radio" name="footlog" value="on" <?php echo (get_option('footlog') == 'on') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Aktifkan', 'weesata'); ?></span> 
		        	</div>
		        	<div class="quarter">
		    	    	<input type="radio" name="footlog" value="off" <?php echo (get_option('footlog') == 'off') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('Nonaktifkan', 'weesata'); ?></span>
		        	</div>
				</div>
	    	</td>
    	</tr>
			
