<?php get_header(); ?>

    	<div class="container">
            <div class="notfound">
		        	<h1>
			        	Konten Tidak Ditampilkan
		        	</h1>
			    	Data Slide Gambar tidak ditampilkan dihalaman ini, Slide Gambar hanya ditampilkan pada halaman Beranda.
				</div>
    	</div>

<?php get_footer(); ?>
