<?php get_header(); ?>

    	<div class="container">
            <div class="notfound">
		        	<h1>
			        	Konten Tidak Ditampilkan
		        	</h1>
			    	Jadwal Jum'at tidak ditampilkan di halaman ini, silahkan cek halaman <a href="<?php echo get_post_type_archive_link( 'jadwal-jumat' ); ?>">Jadwal Jumat</a> untuk melihatnya.
				</div>
    	</div>

<?php get_footer(); ?>
